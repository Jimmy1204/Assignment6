package Jimmy;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.ListSelectionModel;




public class Pay extends JFrame
{
	
	JButton b1,b2,b3;
	JLabel l1,l2;
	JList list;
	String[] name = new String[12];
	String[] line = new String[12];
	int[] id = new int[12];
	int[] num = new int[12];
	int[] price = new int[12];
	PetSQL p = new PetSQL();
	
	PetGUI[] g = new PetGUI[12];
	public Pay() throws ClassNotFoundException, SQLException 
	{
		// TODO Auto-generated constructor stub
		
		for(int i =0;i < 12;i++)
			g[i] = new PetGUI(i); 
		for(int i =0,j = 0;i < 12;i++)
		{
			if(g[i].getAddCount(i) > 0)
			{
				name[j] = p.names[i];
				id[j] = i;
				num[j] = g[i].getAddCount(i);
				price[j] = Integer.parseInt(p.prices[i])*num[j];
				line[j] = i+"  ��Ʒ���ƣ�"+name[j]+"  ������"+num[j]+"  �۸�"+price[j];
			}
			
		}
		b1 = new JButton("ɾ��");
		b2 = new JButton("����֧��");
		b3 = new JButton("����");
		list = new JList(line);
		list.setBackground(Color.YELLOW);
		list.setVisibleRowCount(6);
		list.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
		
		
		b1.addActionListener(new ActionListener() 
		{
			
			@Override
			public void actionPerformed(ActionEvent e) 
			{
				// TODO Auto-generated method stub
				
			}
		});
		
		b2.addActionListener(new ActionListener() 
		{
			
			@Override
			public void actionPerformed(ActionEvent e) 
			{
				// TODO Auto-generated method stub
				
				showMessage("֧���ɹ��������ۣ�");
				setVisible(false);
				for(int i =0;i < 12;i++)
				{
					if(g[i].getAddCount(i) > 0)
					{
						addComment a = new addComment(i);
						g[i].setAddCount(i, g[i].getAddCount(i)-1); 
						

					}
				}
			}
		});
		
		b3.addActionListener(new ActionListener() 
		{
			
			@Override
			public void actionPerformed(ActionEvent e) 
			{
				// TODO Auto-generated method stub
				setVisible(false);
				PetGUI p;
				try {
					p = new PetGUI(0);
					p.run();
				} catch (ClassNotFoundException | SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}
		});
		
		JPanel panel = new JPanel(new BorderLayout());
		panel.add("North",list);
		JPanel panel2 = new JPanel(new GridLayout(1, 3));
		panel2.add(b1);
		panel2.add(b2);
		panel2.add(b3);
		panel.add("Center",panel2);
		add(panel);
		
		pack();// �Զ����������С
		setLocation(SwingUtil.centreContainer(getSize()));
		setVisible(true);
	}
	
	public void linkSQL(int id,String name,int num,int price) throws SQLException, ClassNotFoundException
	{
		Class.forName("com.mysql.jdbc.Driver"); 
		Connection connection = (Connection) DriverManager.getConnection("jdbc:mysql://127.0.0.1:3306/pet?user=root&password=5511332*ss");
		Statement statement=(Statement) connection.createStatement();
		statement.execute("INSERT INTO pay(id,name,num,price)VALUES('"+id+"','"+name+"','"+num+"','"+price+"')");
		statement.close();
		connection.close();
	}
	
	public void showMessage(String msg) 
	{
		JOptionPane.showMessageDialog(this, msg, "����", JOptionPane.WARNING_MESSAGE);
	}
}
