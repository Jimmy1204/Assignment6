package Jimmy;

import java.sql.SQLException;

public class Main2014302580324 
{
	public static void main(String[] args) throws ClassNotFoundException, SQLException 
	{
		Login a = new Login();
		a.run();
		
	}
}
