package Jimmy;

import java.awt.BorderLayout;
import java.awt.Color;

import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;

import javax.swing.Box;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;

public class Comment extends JFrame 
{	
	JButton b1;
	JTextArea textArea;
	JLabel l1;
	JScrollPane scrollPane;
	
	public Comment(String comment) 
	{
		// TODO Auto-generated constructor stub	
		setTitle("��Ʒ����");
		b1 = new JButton("����");
		b1.setBackground(Color.YELLOW);
		b1.setFont(new Font("΢���ź�",Font.PLAIN,30));
		textArea = new JTextArea(20,10);
		textArea.setText(textArea.getText()+comment+"\n");
		l1 = new JLabel("����Ϊ����Ʒ�����ۣ�",JLabel.CENTER);
		l1.setFont(new Font("΢���ź�",Font.PLAIN,30));
		scrollPane = new JScrollPane(textArea);
		scrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED);
		b1.addActionListener(new ActionListener() 
		{
			
			@Override
			public void actionPerformed(ActionEvent e) 
			{
				// TODO Auto-generated method stub
				setVisible(false);
				PetGUI p;
				try {
					p = new PetGUI(0);
					p.run();
				} catch (ClassNotFoundException | SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}
		});
		Box box = Box.createHorizontalBox();
		box.add(scrollPane);
		JPanel panel = new JPanel(new BorderLayout());
		panel.add("North",l1);
		panel.add("Center",box);
		panel.add("South",b1);
		add(panel);
		pack();// �Զ����������С
		setLocation(SwingUtil.centreContainer(getSize()));
	}
	
	public void run() 
	{
		try
		{
			setVisible(true);
		}catch(Exception e)
		{
			e.printStackTrace();
		}
	}
}
