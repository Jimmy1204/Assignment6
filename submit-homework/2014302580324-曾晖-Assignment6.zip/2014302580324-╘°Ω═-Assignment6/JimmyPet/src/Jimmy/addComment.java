package Jimmy;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextArea;

public class addComment extends JFrame
{
	JTextArea textArea;
	JButton b1,b2;
	String[] comment = new String[12]; 
	public addComment(final int id) 
	{
		// TODO Auto-generated constructor stub
		setTitle("����");
		JPanel panel = new JPanel(new BorderLayout());
		textArea = new JTextArea(10,40);
		b1 = new JButton("����");
		b2 = new JButton("���");
		b1.setBackground(Color.YELLOW);
		b2.setBackground(Color.YELLOW);
		b1.setFont(new Font("΢���ź�",Font.PLAIN,30));
		b2.setFont(new Font("΢���ź�",Font.PLAIN,30));
		
		b1.addActionListener(new ActionListener() 
		{
			
			@Override
			public void actionPerformed(ActionEvent e) 
			{
				// TODO Auto-generated method stub
				comment[id] = textArea.getText();
					showMessage("���۳ɹ���");
				setVisible(false);
				try {
					PetGUI p = new PetGUI(id);
					p.run();
				} catch (ClassNotFoundException | SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}
		});
		
		b2.addActionListener(new ActionListener() 
		{
			
			@Override
			public void actionPerformed(ActionEvent e) 
			{
				// TODO Auto-generated method stub
				textArea.setText("");
			}
		});
		
		JPanel panel1 = new JPanel(new GridLayout(1, 2));
		panel1.add(b1);
		panel1.add(b2);
		panel.add("Center",textArea);
		panel.add("South",panel1);
		add(panel);
		pack();// �Զ����������С
		setLocation(SwingUtil.centreContainer(getSize()));
		
		try
		{
			setVisible(true);
		}catch(Exception e)
		{
			e.printStackTrace();
		}
	}
	
	public void showMessage(String msg) 
	{
		JOptionPane.showMessageDialog(this, msg, "����", JOptionPane.WARNING_MESSAGE);
	}
		
	
}
