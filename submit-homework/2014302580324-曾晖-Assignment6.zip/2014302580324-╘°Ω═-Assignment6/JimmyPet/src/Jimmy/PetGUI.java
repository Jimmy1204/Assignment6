package Jimmy;

import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class PetGUI extends JFrame
{
	private int addCount[] = new int[12];
	

	JButton last,next,add,comment,pay;
	JLabel img,name,eat,drink,live,hobby,price;
	
	ImageIcon[] icon = new ImageIcon[12];
	
	
	
	
	public int getAddCount(int id)
	{
		return addCount[id];
	}
	
	public void setAddCount(int id,int count) 
	{
		this.addCount[id] = count;
	}
	
	public PetGUI(final int id) throws ClassNotFoundException, SQLException 
	{
		// TODO Auto-generated constructor stub
		PetSQL p = new PetSQL();
		for(int i = 0;i < 12;i++)
		{
			addCount[i] = 0;
		}
		setTitle("������Ϣ");
		addCount = new int[15];
		for(int i = 0;i < 12;i++)
		{
			int a = i+1;
			icon[i] = new ImageIcon("src/Jimmy/"+a+".jpg");
		}
		img = new JLabel("");
		img.setIcon(icon[id]);		
		last = new JButton("��һ��");
		next = new JButton("��һ��");
		add = new JButton("���빺�ﳵ");
		pay = new JButton("�ҵĹ��ﳵ");
		comment = new JButton("�鿴����");
		last.setFont(new Font("΢���ź�",Font.PLAIN,25));
		next.setFont(new Font("΢���ź�",Font.PLAIN,25));
		pay.setFont(new Font("΢���ź�",Font.PLAIN,25));
		add.setFont(new Font("΢���ź�",Font.PLAIN,30));
		comment.setFont(new Font("΢���ź�",Font.PLAIN,30));
		last.setBackground(Color.LIGHT_GRAY);
		next.setBackground(Color.LIGHT_GRAY);
		pay.setBackground(Color.LIGHT_GRAY);
		add.setBackground(Color.YELLOW);
		comment.setBackground(Color.YELLOW);
		
		last.addActionListener(new ActionListener() 
		{
			
			@Override
			public void actionPerformed(ActionEvent e) 
			{
				// TODO Auto-generated method stub
				
				if(id - 1 >= 0)
				{
					setVisible(false);
					int count = id - 1;
					PetGUI p;
					try {
						p = new PetGUI(count);
						p.run();
					} catch (ClassNotFoundException | SQLException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
				}
			}
		});
		
		next.addActionListener(new ActionListener() 
		{
			
			@Override
			public void actionPerformed(ActionEvent e) 
			{
				// TODO Auto-generated method stub
				if(id +1 <= 11)
				{
					setVisible(false);
				
					int count = id + 1;
					PetGUI p;
					try {
						p = new PetGUI(count);
						p.run();
					} catch (ClassNotFoundException | SQLException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
				}
			}
		});
		
		add.addActionListener(new ActionListener() 
		{
			
			@Override
			public void actionPerformed(ActionEvent e) 
			{
				// TODO Auto-generated method stub
				addCount[id]++;				
			}
		});
		
		comment.addActionListener(new ActionListener() 
		{
			
			@Override
			public void actionPerformed(ActionEvent e) 
			{
				// TODO Auto-generated method stub
				setVisible(false);
				Comment cs[] = new Comment[12];
				cs[id] = new Comment("23");
				cs[id].run();
			}
		});
		
		pay.addActionListener(new ActionListener() 
		{
			
			@Override
			public void actionPerformed(ActionEvent e) 
			{
				// TODO Auto-generated method stub
				setVisible(false);
				try {
					Pay pay = new Pay();
				} catch (ClassNotFoundException | SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				
			}
		});
		
		this.name = new JLabel(p.names[id],JLabel.CENTER);
		this.eat = new JLabel("��"+p.eats[id],JLabel.CENTER);
		this.drink = new JLabel("��"+p.drinks[id],JLabel.CENTER);
		this.live = new JLabel("ס"+p.lives[id],JLabel.CENTER);
		this.hobby = new JLabel("ϰ��"+p.hobbies[id],JLabel.CENTER);
		this.price = new JLabel("����"+p.prices[id],JLabel.CENTER);
		name.setForeground(Color.BLUE);
		name.setFont(new Font("΢���ź�",Font.BOLD,50));
		eat.setFont(new Font("΢���ź�",Font.PLAIN,30));
		drink.setFont(new Font("΢���ź�",Font.PLAIN,30));
		live.setFont(new Font("΢���ź�",Font.PLAIN,30));
		hobby.setFont(new Font("΢���ź�",Font.PLAIN,30));
		price.setFont(new Font("΢���ź�",Font.CENTER_BASELINE,40));
		price.setForeground(Color.RED);
		eat.setForeground(Color.PINK);
		live.setForeground(Color.PINK);
		hobby.setForeground(Color.PINK);
		drink.setForeground(Color.PINK);
		JPanel panel1 = new JPanel();
		panel1.add(img);
		JPanel panel3 = new JPanel(new GridLayout(1, 3));
		panel3.add(last);
		panel3.add(pay);
		panel3.add(next);
		JPanel panel2 = new JPanel(new GridLayout(9, 1));
		panel2.add(panel3);
		panel2.add(name);
		panel2.add(eat);
		panel2.add(drink);
		panel2.add(live);
		panel2.add(hobby);
		panel2.add(price);
		panel2.add(add);
		panel2.add(comment);
		JPanel panel = new JPanel(new GridLayout(1,2));
		panel.add(panel1);
		panel.add(panel2);
		add(panel);
		pack();// �Զ����������С
		setLocation(SwingUtil.centreContainer(getSize()));// �ô��������ʾ
	}

	
	public void run() 
	{
		try
		{
			setVisible(true);
		}catch(Exception e)
		{
			e.printStackTrace();
		}
	}
	
	
}
