package Jimmy;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.mysql.jdbc.PreparedStatement;

public class PetSQL 
{
	String names[] = new String[12];
	String eats[] = new String[12];
	String drinks[] = new String[12];
	String lives[] = new String[12];
	String hobbies[] = new String[12];
	String prices[] = new String[12];
	
	int ids[] = new int[12]; 
	
	public PetSQL() throws SQLException, ClassNotFoundException 
	{
		// TODO Auto-generated constructor stub
		Class.forName("com.mysql.jdbc.Driver"); 
		Connection connection = (Connection) DriverManager.getConnection("jdbc:mysql://127.0.0.1:3306/pet?user=root&password=5511332*ss");
		Statement statement = connection.createStatement();
		PreparedStatement preparedStatement = (PreparedStatement) connection.prepareStatement("SELECT * FROM pet WHERE price LIKE ?");
		preparedStatement.setString(1, "%"+""+"%");
		ResultSet resultSet = preparedStatement.executeQuery();
		for(int i = 0;resultSet.next();i++)
		{
			
			ids[i] = Integer.parseInt(resultSet.getString(1));
			names[i] = resultSet.getString(2);
			eats[i] = resultSet.getString(3);
			drinks[i] = resultSet.getString(4);
			lives[i] = resultSet.getString(5);
			hobbies[i] = resultSet.getString(6);
			prices[i] = resultSet.getString(7);
		}
			
	}	
}
