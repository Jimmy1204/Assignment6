package Jimmy;

import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;

import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import org.apache.commons.lang.RandomStringUtils;  

public class Login extends JFrame
{
	private JPanel contentPane;
	private JTextField usernameTextField;
	private JPasswordField passwordField;
	private JTextField validateTextField;
	private String randomText;

	public void run()
	{
		try
		{
			Login frame=new Login();
			frame.setVisible(true);
		}catch(Exception e)
		{
			e.printStackTrace();
		}
	}

	public Login()
	{
		setTitle("�����̵�");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		contentPane=new JPanel();
		setContentPane(contentPane);
		contentPane.setLayout(new BoxLayout(contentPane,BoxLayout.PAGE_AXIS));
		JPanel usernamePanel=new JPanel();
		contentPane.add(usernamePanel);
		JLabel usernameLable=new JLabel("\u7528\u6237\u540D\uFF1A");
		usernameLable.setFont(new Font("΢���ź�", Font.PLAIN, 15));
		usernamePanel.add(usernameLable);

		usernameTextField=new JTextField();
		usernameTextField.setFont(new Font("΢���ź�", Font.PLAIN, 15));
		usernamePanel.add(usernameTextField);
		usernameTextField.setColumns(10);

		JPanel passwordPanel = new JPanel();
		contentPane.add(passwordPanel);
		JLabel passwordLabel = new JLabel("\u5BC6 \u7801\uFF1A");
		passwordLabel.setFont(new Font("΢���ź�", Font.PLAIN, 15));
		passwordPanel.add(passwordLabel);
		passwordField = new JPasswordField();
		passwordField.setColumns(10);
		passwordField.setFont(new Font("΢���ź�", Font.PLAIN, 15));
		passwordPanel.add(passwordField);
		JPanel validatePanel = new JPanel();
		contentPane.add(validatePanel);
		JLabel validateLabel = new JLabel("\u9A8C\u8BC1\u7801\uFF1A");
		validateLabel.setFont(new Font("΢���ź�", Font.PLAIN, 15));
		validatePanel.add(validateLabel);
		validateTextField = new JTextField();
		validateTextField.setFont(new Font("΢���ź�", Font.PLAIN, 15));
		validatePanel.add(validateTextField);
		validateTextField.setColumns(5);
		randomText = RandomStringUtils.randomAlphanumeric(4);
		CheckLabel label = new CheckLabel(randomText);//�����֤��
		label.setFont(new Font("΢���ź�", Font.PLAIN, 15));
		validatePanel.add(label);
		
		JPanel buttonPanel=new JPanel();
		contentPane.add(buttonPanel);

		JButton submitButton=new JButton("��¼");
		submitButton.setBackground(Color.YELLOW);
		
		submitButton.addActionListener(new ActionListener() 
		{
			@Override
			public void actionPerformed(ActionEvent e) 
			{

				if (usernameTextField.getText().isEmpty()) 
				{
					// �ж��û����Ƿ�Ϊ��
					showMessage("�û�������Ϊ�գ�");
					return;
				}
				if (new String(passwordField.getPassword()).isEmpty()) 
				{
					// �ж������Ƿ�Ϊ��
					showMessage("���벻��Ϊ�գ�");
					return;
				}
				if (validateTextField.getText().isEmpty()) 
				{
					// �ж���֤���Ƿ�Ϊ��
					showMessage("��֤�벻��Ϊ�գ�");
					return;
				}
				if(!validateTextField.getText().equals(randomText))
				{
					showMessage("��֤�����");
					return;
				}
				SQL sql = new SQL();
				
				try {
					if(!sql.isExist(usernameTextField.getText()))
					{
						showMessage("�û���������!");
						return;
					}
				} catch (ClassNotFoundException | SQLException e2) {
					// TODO Auto-generated catch block
					e2.printStackTrace();
				}
				
				setVisible(false);
				try {
					PetGUI p = new PetGUI(0);
					p.run();
				} catch (ClassNotFoundException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				
			}
		});
		
		submitButton.setFont(new Font("΢���ź�", Font.PLAIN, 15));
		buttonPanel.add(submitButton);

		JButton signButton=new JButton("ע��");
		signButton.setBackground(Color.YELLOW);
		signButton.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent e)
			{
				setVisible(false);
				SignGUI s = new SignGUI();
				s.run();
			}
		});
		
		signButton.setFont(new Font("΢���ź�",Font.PLAIN,15));
		buttonPanel.add(signButton);

		pack();// �Զ����������С
		setLocation(SwingUtil.centreContainer(getSize()));// �ô��������ʾ

	}
	
	public void showMessage(String msg) 
	{
		JOptionPane.showMessageDialog(this, msg, "����", JOptionPane.WARNING_MESSAGE);
	}
}

