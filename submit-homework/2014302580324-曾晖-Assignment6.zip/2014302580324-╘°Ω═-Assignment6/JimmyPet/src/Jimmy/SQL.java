package Jimmy;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.mysql.jdbc.PreparedStatement;

public class SQL 
{
	public void userSQL(String id,String password,String email) throws SQLException, ClassNotFoundException
	{
		Class.forName("com.mysql.jdbc.Driver"); 
		Connection connection = (Connection) DriverManager.getConnection("jdbc:mysql://127.0.0.1:3306/user?user=root&password=5511332*ss");
		Statement statement=(Statement) connection.createStatement();
		statement.execute("INSERT INTO 2014302580324_user(�û���,����,��������)VALUES('"+id+"','"+password+"','"+email+"')");
		statement.close();
		connection.close();
	}
	
	public boolean isExist(String id) throws ClassNotFoundException, SQLException 
	{
		Class.forName("com.mysql.jdbc.Driver"); 
		Connection connection = (Connection) DriverManager.getConnection("jdbc:mysql://127.0.0.1:3306/user?user=root&password=5511332*ss");
		Statement statement = connection.createStatement();
		PreparedStatement preparedStatement = (PreparedStatement) connection.prepareStatement("SELECT * FROM 2014302580324_user WHERE �û���   LIKE ?");
		preparedStatement.setString(1,id);
		ResultSet resultSet = preparedStatement.executeQuery();
		if(resultSet.next())
			return true;
		return false;
	}
	

}
