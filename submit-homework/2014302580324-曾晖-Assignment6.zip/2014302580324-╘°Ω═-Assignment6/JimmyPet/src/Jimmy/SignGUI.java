package Jimmy;

import java.awt.Color;
import java.awt.Component;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.Raster;
import java.sql.SQLException;

import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;

public class SignGUI extends JFrame
{

	private JPanel contentPane;
	private JTextField usernameTextField;
	private JPasswordField passwordField1;
	private JPasswordField passwordField2;
	private JTextField emailTextField;
	private JLabel tipLabel = new JLabel();

		public void run() 
		{
			try {
				SignGUI frame = new SignGUI();
				frame.setVisible(true);
			} catch (Exception e) {
				e.printStackTrace();
			}
		}

		/**
		* Create the frame.
		*/
		public 	SignGUI() 
		{
			setTitle("\u7528\u6237\u6CE8\u518C");
			setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
			contentPane = new JPanel();
			setContentPane(contentPane);
			contentPane.setLayout(new BoxLayout(contentPane, BoxLayout.PAGE_AXIS));
			JPanel usernamePanel = new JPanel();
			contentPane.add(usernamePanel);
			JLabel usernameLabel = new JLabel("\u7528 \u6237 \u540D\uFF1A");
			usernameLabel.setFont(new Font("΢���ź�", Font.PLAIN, 15));
			usernamePanel.add(usernameLabel);
			usernameTextField = new JTextField();
			usernameTextField.setToolTipText("\u8BF7\u8F93\u51655~15\u4E2A\u7531\u5B57\u6BCD\u6570\u5B57\u4E0B\u5212\u7EBF\u7EC4\u6210\u7684\u5B57\u7B26\u4E32");
			usernameTextField.setFont(new Font("΢���ź�", Font.PLAIN, 15));
			usernamePanel.add(usernameTextField);
			usernameTextField.setColumns(10);
			JPanel passwordPanel1 = new JPanel();
			contentPane.add(passwordPanel1);
			JLabel passwordLabel1 = new JLabel("\u8F93\u5165\u5BC6\u7801\uFF1A");
			passwordLabel1.setFont(new Font("΢���ź�", Font.PLAIN, 15));
			passwordPanel1.add(passwordLabel1);
			passwordField1 = new JPasswordField();
			passwordField1.setFont(new Font("΢���ź�", Font.PLAIN, 15));
			passwordField1.setColumns(10);
			passwordPanel1.add(passwordField1);
			JPanel passwordPanel2 = new JPanel();
			contentPane.add(passwordPanel2);
			JLabel passwordLabel2 = new JLabel("\u786E\u8BA4\u5BC6\u7801\uFF1A");
			passwordLabel2.setFont(new Font("΢���ź�", Font.PLAIN, 15));
			passwordPanel2.add(passwordLabel2);
			passwordField2 = new JPasswordField();
			passwordField2.setFont(new Font("΢���ź�", Font.PLAIN, 15));
			passwordField2.setColumns(10);
			passwordPanel2.add(passwordField2);
			JPanel emailPanel = new JPanel();
			contentPane.add(emailPanel);
			JLabel emailLabel = new JLabel("\u7535\u5B50\u90AE\u7BB1\uFF1A");
			emailLabel.setFont(new Font("΢���ź�", Font.PLAIN, 15));
			emailPanel.add(emailLabel);
			emailTextField = new JTextField();
			emailTextField.setFont(new Font("΢���ź�", Font.PLAIN, 15));
			emailPanel.add(emailTextField);
			emailTextField.setColumns(10);
			JPanel buttonPanel = new JPanel();
			contentPane.add(buttonPanel);
			JButton submitButton = new JButton("\u63D0\u4EA4");
			submitButton.setBackground(Color.YELLOW);
			submitButton.addActionListener(new ActionListener() 
			{
				@Override
				public void actionPerformed(ActionEvent e) 
				{
					if (usernameTextField.getText().isEmpty()) 
					{// �ж��û����Ƿ�Ϊ��
						showMessage("�û�������Ϊ�գ�");
						return;
					}
					if (new String(passwordField1.getPassword()).isEmpty()) 
					{// �ж������Ƿ�Ϊ��
						showMessage("���벻��Ϊ�գ�");
						return;
					}
					if (new String(passwordField2.getPassword()).isEmpty()) 
					{// �ж�ȷ�������Ƿ�Ϊ��
						showMessage("ȷ�����벻��Ϊ�գ�");
						return;
					}
					if (emailTextField.getText().isEmpty()) 
					{// �жϵ��������Ƿ�Ϊ��
							showMessage("�������䲻��Ϊ�գ�");
						return;
					}
					// У����������������Ƿ���ͬ
					if(!(new String(passwordField1.getPassword()).equals(new String(passwordField2.getPassword()))))
					{
						showMessage("�������벻һ�£�");
						return;
					}
					
					
					SQL sql = new SQL();
					
					try {
						if(sql.isExist(usernameTextField.getText()))
						{
							showMessage("�û����Ѵ��ڣ�");
							return;
						}
					} catch (ClassNotFoundException | SQLException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
					
					try {
						sql.userSQL(usernameTextField.getText(), new String(passwordField1.getPassword()),emailTextField.getText());
					} catch (ClassNotFoundException | SQLException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
					showMessage("ע��ɹ�!");
					setVisible(false);
					Login l = new Login();
					l.run();
				}
			});
			buttonPanel.setLayout(new BoxLayout(buttonPanel, BoxLayout.LINE_AXIS));
			tipLabel.setFont(new Font("΢���ź�", Font.PLAIN, 15));
			buttonPanel.add(tipLabel);
			Component glue = Box.createGlue();
			buttonPanel.add(glue);
			submitButton.setFont(new Font("΢���ź�", Font.PLAIN, 15));
			buttonPanel.add(submitButton);
			JButton cancelButton = new JButton("\u53D6\u6D88");
			cancelButton.setBackground(Color.YELLOW);
			cancelButton.addActionListener(new ActionListener() 
			{
				@Override
				public void actionPerformed(ActionEvent e) 
				{
					System.exit(0);
				}
			});
			cancelButton.setFont(new Font("΢���ź�", Font.PLAIN, 15));
			buttonPanel.add(cancelButton);
			pack();// �Զ����������С
			setLocation(SwingUtil.centreContainer(getSize()));// �ô��������ʾ
		}

		public void showMessage(String msg) 
		{
			JOptionPane.showMessageDialog(this, msg, "����", JOptionPane.WARNING_MESSAGE);
		}
	
}
